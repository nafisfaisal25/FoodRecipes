package com.example.foodrecipes.adapters;

public interface OnRecipeListener {
    public void onItemSelected(int position);
    public void onCategorySelected(String category);
}
